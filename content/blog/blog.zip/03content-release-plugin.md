---
title: Content Release Plugin
author: rkadmin
type: post
date: 2019-03-19T02:39:05+00:00
draft: true
private: true
url: /content-release-plugin/
categories:
  - Interests

---
Wish there was a way you can release content at a specific time?

You can do that with this plugin.

This is a very light-weight plugin, and should have no conflicts with other plugins.

It was developed by Mirasee to release content at specific times, to best support our students within our courses. As a course developer, I find myself doing this very often. 



### How to use

### Use Cases

**Having time released video.** 

[Show BEFORE/AFTER image &#8211; CBB]

**You have a online course. And your lessons are released on certain days.**

 ****[SHOW IMAGE of BIB &#8211; BEFORE and AFTER.] &#8212; BEFORE -> https://i.imgur.com/uLwy8mG.png

Your blog site has a special downloadable that will be unlocked.

[SHOW BEFORE/AFTER IMAGE]



### Limitations

fdfdf

### Learn more about Cohort-based learning

There is hundreds and hundreds of studies that show that education works when &#8212; A cohort is a group of students who work through a curriculum together to achieve the same academic training together. 

And to do that, content must be released in time.